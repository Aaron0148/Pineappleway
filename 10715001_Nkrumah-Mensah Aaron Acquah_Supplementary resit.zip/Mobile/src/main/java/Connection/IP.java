package Connection;

public class IP {


    public static String baseURL = "http://192.168.100.6:8282/";


    public static String signIn = baseURL + "/customer/sign_in";
    public static String order = baseURL + "/customer/save_order";
    public static String SignUpUrl = baseURL + "/customer/create_account";
}
