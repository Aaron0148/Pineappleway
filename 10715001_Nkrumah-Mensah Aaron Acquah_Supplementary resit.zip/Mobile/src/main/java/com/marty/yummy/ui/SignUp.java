package com.marty.yummy.ui;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.marty.yummy.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import Connection.Https;

import static Connection.IP.SignUpUrl;
import static Connection.IP.signIn;

public class SignUp  extends AppCompatActivity {

    String responseCode = null;
    String responseMessage = null;
    String profileData = null;
    TextView usernametxt,passwordtxt ,phonetxt ,locationtxt;
    Button signUpButton;
    String username = "", fullname = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);
        //declare this to hide the app bar
        getSupportActionBar().hide();
        setContentView(R.layout.sign_up);


//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);


        usernametxt = findViewById(R.id.Name);
        passwordtxt = findViewById(R.id.edtPassword);
        locationtxt = findViewById(R.id.edtLocation) ;
        phonetxt = findViewById(R.id.edtPhone) ;
        signUpButton       = findViewById(R.id.btnSignUp);



//        sharedPreferences = getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
//        prefsEditor = sharedPreferences.edit();

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SignUpAuth();
            }
        });

    }







    private void SignUpAuth(){

        {
            final String json = ParamstoJSON();

            AsyncTask<Void, Void, String> task = new AsyncTask<Void, Void, String>() {


                @Override
                protected void onPreExecute() {
                    super.onPreExecute();

                    // dialog.show();

                }


                @Override
                protected String doInBackground(Void... voids) {
                    return Https.ServerResponse(json, SignUpUrl);
                }

                @Override
                protected void onPostExecute(String result) {
                    //  dialog.dismiss();

                    super.onPostExecute(result);
                    if (result != null) {
                        // Do you work here on success

                        if (result.equals("unsuccessful")) {

                            //  alert.showDialogInternet(ctx);

                        } else if (result.equals("exception")) {

                            //  alert.showDialogInternet(ctx);

                        } else if (result.equals("[]")) {


                        } else {

                            System.out.println("LOGIN AUTH :: " + result);


                            try {

                                JSONObject json = (JSONObject) new JSONTokener(result).nextValue();

                                responseCode = json.getString("responseCode");
                                responseMessage = json.getString("responseMessage");
                               // profileData = json.getString("profile");


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            if (responseCode.equals("515")) {

                                // alert.showGeneralAlert(ctx, "Failed", "Wrong username or password. Please check and try again");

                                Toast.makeText(SignUp.this, "Wrong credentials\n" , Toast.LENGTH_LONG).show();


                            }
                            else if (responseCode.equals("511")) {

                                Toast.makeText(SignUp.this, "Wrong credentials\n" , Toast.LENGTH_LONG).show();
                            }




                            else if (responseCode.equals("000")) {

                                // Toast.makeText(SignIn.this, "success\n" + result, Toast.LENGTH_LONG).show();
//                                try {
//
//                                    JSONArray array = new JSONArray(profileData);
//
//                                    for (int i = 0; i < array.length(); i++) {
//
//                                        JSONObject object = array.getJSONObject(i);
//
//                                        username = (object.getString("username"));
//                                        fullname = (object.getString("fullname"));
//
//
//                                    }
//
////                                    prefsEditor.putString("username", username);
////
////                                    prefsEditor.commit();
//
//
//
//                                    Toast.makeText(SignUp.this, "Success\n" , Toast.LENGTH_LONG).show();
//
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }


                                Toast.makeText(SignUp.this, "Success\n" , Toast.LENGTH_LONG).show();
                                // Toast.makeText(ctx, Profile.getPolicy_number(), Toast.LENGTH_LONG).show();



//                                    Intent intent = new Intent(ctx, HomeScreenActivity.class);
//                                    startActivity(intent);
//                                    overridePendingTransition(R.anim.anim_slide_in_left,
//                                            R.anim.anim_slide_out_left);

                                startActivity(new Intent(SignUp.this,SignIn.class));

                                finish();





                            }


                        }

                    } else {
                        // null response or Exception occur
                    }

                }
            };

            task.execute();
        }
    }




    public String ParamstoJSON() {

        // mobileNumber = login_phone.getText().toString().trim();

        // Toast.makeText(this, "+" + countryCode + mobileNumber, Toast.LENGTH_LONG).show();

        JSONObject jsonObject = new JSONObject();
        try {

//            jsonObject.put("phone", "+" + countryCode + mobileNumber);
//            jsonObject.put("pin", login_password.getEditText().getText().toString());
            jsonObject.put("username", usernametxt.getText().toString().trim() );
            jsonObject.put("phone", phonetxt.getText().toString().trim());
            jsonObject.put("address", locationtxt.getText().toString().trim());
            jsonObject.put("password", passwordtxt.getText().toString().trim());


            return jsonObject.toString();
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "";
        }
    }

}
