package com.marty.yummy.ui;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import android.widget.Toast;

import com.marty.yummy.R;
import com.marty.yummy.model.CartItem;
import com.marty.yummy.ui.adapters.CartListAdapter;
import com.marty.yummy.viewmodel.CartViewModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.List;

import Connection.Https;

import static Connection.IP.order;

public class CartActivity extends AppCompatActivity implements View.OnClickListener {

    RecyclerView cartList;
    TextView tDiscount,hDiscount,tItemsCost,tDelivery,hDelivery,tGrandTotal;
    TextInputEditText eCoupon;
    TextInputLayout eCouponLayout;
    AppCompatButton bApply;
    AppCompatImageView iRemoveCoupon;
    CartViewModel cartViewModel;
    Observer<List<CartItem>> cartObserver;
    Observer<Double> costObserver;
    Observer<String> errorObserver;
    CartListAdapter cartListAdapter;

    String finalTotal= null;

    public static SharedPreferences sharedPreferences;
    public static SharedPreferences.Editor prefsEditor;
    public static final String PREFERENCES = "Prefs";


    String responseCode = null;
    String responseMessage = null;
    String profileData = null;
    String username = "";
    String finalQuantity = "";
    String foodname = "";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        setTitle(R.string.your_cart);
        if(getSupportActionBar()!=null){
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        cartList = findViewById(R.id.cart_list);
        tDiscount = findViewById(R.id.t_discount);
        tItemsCost = findViewById(R.id.t_total);
        hDiscount = findViewById(R.id.h_discount);
        tDelivery = findViewById(R.id.t_delivery);
        hDelivery = findViewById(R.id.h_delivery);
        iRemoveCoupon = findViewById(R.id.i_remove);
        tGrandTotal = findViewById(R.id.t_grand_total);
        eCouponLayout = findViewById(R.id.coupon_layout);
        eCoupon = findViewById(R.id.e_coupon);
        bApply = findViewById(R.id.b_apply);
        bApply.setOnClickListener(this);
        iRemoveCoupon.setOnClickListener(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        cartList.setLayoutManager(mLayoutManager);

        sharedPreferences = getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
        prefsEditor = sharedPreferences.edit();

        username = sharedPreferences.getString("username", "");
        finalQuantity = sharedPreferences.getString("quantity", "");
        foodname = sharedPreferences.getString("foodname", "");



        // Toast.makeText(ctx, Profile.getPolicy_number(), Toast.LENGTH_LONG).show();
      //  Toast.makeText(CartActivity.this, username , Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        cartObserver = new Observer<List<CartItem>>() {
            @Override
            public void onChanged(@Nullable List<CartItem> cartItems) {
                cartListAdapter.setData(cartItems);
                cartListAdapter.notifyDataSetChanged();
                if(cartItems!=null && cartItems.size()==0){
                    finish();
                }
            }
        };
        costObserver = new Observer<Double>() {
            @Override
            public void onChanged(@Nullable Double aDouble) {
                updateUI(aDouble);

                finalTotal= aDouble.toString();
            }
        };
        errorObserver = new Observer<String>() {
            @Override
            public void onChanged(@Nullable String error) {
                if(error!=null && error.isEmpty()){
                    eCouponLayout.setError(null);
                    eCouponLayout.setErrorEnabled(false);
                }else{
                    eCouponLayout.setError(error);
                    eCouponLayout.setErrorEnabled(true);
                }
            }
        };
        cartViewModel = ViewModelProviders.of(this).get(CartViewModel.class);
        cartListAdapter = new CartListAdapter(new ArrayList<CartItem>(),cartViewModel);
        cartList.setAdapter(cartListAdapter);
        cartViewModel.getCartItemsLiveData().observe(this,cartObserver);
        cartViewModel.getGrandTotal().observe(this,costObserver);
        cartViewModel.getErrorString().observe(this,errorObserver);
        eCoupon.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i==EditorInfo.IME_ACTION_DONE){
                    applyCoupon();
                    return false;
                }
                return false;
            }
        });
    }


  // to save details in DB
    public void Order(View view) {


       // prefsEditor.ge;

//        sharedPreferences = getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
//        prefsEditor = sharedPreferences.edit();
//
//        String username = sharedPreferences.getString("username", "");
//
//       // Toast.makeText(ctx, Profile.getPolicy_number(), Toast.LENGTH_LONG).show();
//        Toast.makeText(CartActivity.this, username , Toast.LENGTH_LONG).show();
       // prefsEditor.commit();


       saveorder ();

    }


    private void saveorder(){

        {
            final String json = ParamstoJSON();

            AsyncTask<Void, Void, String> task = new AsyncTask<Void, Void, String>() {


                @Override
                protected void onPreExecute() {
                    super.onPreExecute();

                    // dialog.show();

                }


                @Override
                protected String doInBackground(Void... voids) {
                    return Https.ServerResponse(json, order);
                }

                @Override
                protected void onPostExecute(String result) {
                    //  dialog.dismiss();

                    super.onPostExecute(result);
                    if (result != null) {
                        // Do you work here on success

                        if (result.equals("unsuccessful")) {

                            //  alert.showDialogInternet(ctx);

                        } else if (result.equals("exception")) {

                            //  alert.showDialogInternet(ctx);

                        } else if (result.equals("[]")) {


                        } else {

                            System.out.println("LOGIN AUTH :: " + result);


                            try {

                                JSONObject json = (JSONObject) new JSONTokener(result).nextValue();

                                responseCode = json.getString("responseCode");
                                responseMessage = json.getString("responseMessage");
                                profileData = json.getString("profile");


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            if (responseCode.equals("515")) {

                                // alert.showGeneralAlert(ctx, "Failed", "Wrong username or password. Please check and try again");

                                Toast.makeText(CartActivity.this, "Error\n" , Toast.LENGTH_LONG).show();


                            }
                            else if (responseCode.equals("511")) {

                                Toast.makeText(CartActivity.this, "Wrong credentials\n" , Toast.LENGTH_LONG).show();
                            }




                            else if (responseCode.equals("000")) {


                                Toast.makeText(CartActivity.this, "Successful saved Order\n" , Toast.LENGTH_LONG).show();

                                // Toast.makeText(SignIn.this, "success\n" + result, Toast.LENGTH_LONG).show();
//                                try {
//
//                                    JSONArray array = new JSONArray(profileData);
//
//                                    for (int i = 0; i < array.length(); i++) {
//
//                                        JSONObject object = array.getJSONObject(i);
//
//                                        username = (object.getString("username"));
//                                        fullname = (object.getString("fullname"));
//
//
//                                    }
//
//
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }



                                // Toast.makeText(ctx, Profile.getPolicy_number(), Toast.LENGTH_LONG).show();



//                                    Intent intent = new Intent(ctx, HomeScreenActivity.class);
//                                    startActivity(intent);
//                                    overridePendingTransition(R.anim.anim_slide_in_left,
//                                            R.anim.anim_slide_out_left);

                                startActivity(new Intent(CartActivity.this,HomeScreenActivity.class));

                                finish();





                            }


                        }

                    } else {
                        // null response or Exception occur
                    }

                }
            };

            task.execute();
        }
    }



    public String ParamstoJSON() {

        // mobileNumber = login_phone.getText().toString().trim();

        // Toast.makeText(this, "+" + countryCode + mobileNumber, Toast.LENGTH_LONG).show();

        JSONObject jsonObject = new JSONObject();
        try {

//            jsonObject.put("phone", "+" + countryCode + mobileNumber);
//            jsonObject.put("pin", login_password.getEditText().getText().toString());
            jsonObject.put("price",finalTotal);
            jsonObject.put("quantity",finalQuantity);
            jsonObject.put("username",username);

            jsonObject.put("foodname",foodname);



            return jsonObject.toString();
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "";
        }


}



    private void updateUI(Double grandTotal) {
        tItemsCost.setText("₵"+" "+cartViewModel.getTotalCost());
        tGrandTotal.setText("₵"+" "+String.valueOf(grandTotal));
        if(cartViewModel.getDiscountAmt()>0){
            hDiscount.setVisibility(View.VISIBLE);
            tDiscount.setVisibility(View.VISIBLE);
            hDiscount.setText(getString(R.string.discount)+" ( 20% )");
            tDiscount.setText(" - "+"₵"+" "+String.valueOf(cartViewModel.getDiscountAmt()));
        }else{
            hDiscount.setVisibility(View.GONE);
            tDiscount.setVisibility(View.GONE);
        }
        if(cartViewModel.getDeliveryCost()>0){
            hDelivery.setText(getString(R.string.delivery_charges));
            tDelivery.setText(" + "+"₵"+" "+String.valueOf(cartViewModel.getDeliveryCost()));
            tDelivery.setPaintFlags(0);
        }else{
            hDelivery.setText(getString(R.string.delivery_charges)+" ( Free )");
            tDelivery.setText(" + "+"₵"+" 30.00");
            tDelivery.setPaintFlags(tDelivery.getPaintFlags()| Paint.STRIKE_THRU_TEXT_FLAG);
        }
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.b_apply){
            applyCoupon();
        }else if(view.getId() == R.id.i_remove){
            eCoupon.setFocusable(true);
            eCoupon.setFocusableInTouchMode(true);
            eCoupon.setText("");
            eCoupon.setLongClickable(true);
            eCouponLayout.setErrorEnabled(false);
            eCouponLayout.setError(null);
            iRemoveCoupon.setVisibility(View.INVISIBLE);
            bApply.setVisibility(View.VISIBLE);
            cartViewModel.applyCoupon("");
        }
    }

    private void applyCoupon() {
        if(eCoupon.getText()!=null) {
            String coupon = eCoupon.getText().toString().trim().toUpperCase();
            if (!coupon.isEmpty() && (coupon.equals("FREEDEL") || coupon.equals("F22LABS"))) {
                eCouponLayout.setErrorEnabled(false);
                eCouponLayout.setError(null);
                cartViewModel.applyCoupon(coupon);
                eCoupon.setFocusable(false);
                eCoupon.setFocusableInTouchMode(false);
                eCoupon.setLongClickable(false);
                iRemoveCoupon.setVisibility(View.VISIBLE);
                bApply.setVisibility(View.INVISIBLE);
            } else {
                eCouponLayout.setErrorEnabled(true);
                eCouponLayout.setError("coupon not valid");
            }
        }
    }

    @Override
    protected void onDestroy() {
        cartViewModel.getCartItemsLiveData().removeObserver(cartObserver);
        cartViewModel.getGrandTotal().removeObserver(costObserver);
        cartViewModel.getErrorString().removeObserver(errorObserver);
        super.onDestroy();
    }
}
