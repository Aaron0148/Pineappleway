-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 05, 2019 at 11:40 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pine`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `Name` varchar(250) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Mobile` varchar(250) NOT NULL,
  `Subject` varchar(250) NOT NULL,
  `Message` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Name`, `Email`, `Mobile`, `Subject`, `Message`) VALUES
('Kwame', 'kwame@gmail.com', '0502350919', 'Pineapple Way', 'When do I get my pine?'),
('Phoebe', 'phoebe@gmail.com', '0200296501', 'Hey', 'Pineapple Way wow '),
('beans', 'beans@gmail.com', '0208483920', 'Pine', 'Is there an agenda tomorrow?'),
('sd', 'sdf@gmail.com', '1222222222', 'msm', 'knsad'),
('aa', 'aa@gmail.com', '0502350919', 'ade', 'aded'),
('ofli', 'ofli@gmail.com', '83938393839', 'whoosh', 'whoosh'),
('amthereal', 'amthereal@gmail.com', '98323', 'amthereal', 'amthereal'),
('pineyy', 'pineyy@gmail.com', '999', 'pineyy', 'pineyy'),
('ha', 'haha@g.com', '445', 'gaga', 'gagaa');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `username` varchar(30) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`username`, `fullname`, `email`, `contact`, `address`, `password`) VALUES
('aa', 'Pick up', 'aa@gmail.com', 'a928', 'j9ao2', 'aa'),
('bim', 'bim', 'bim@gmail.com', '092', 'bim bim bim', 'bim'),
('birju', 'BIRJU KUMAR', 'bkm123r@gmail.com', '8903079750', 'Pondicherry University, SRK HOSTEL ROOM NUMBER-59,', 'Birju123@'),
('China', 'pickup', 'china@gmail.com', '2902', 'china', 'china'),
('ckumar', 'CHANDAN KUMAR', 'ckj40856@gmail.com', '9487810674', 'Pondicherry University, SRK HOSTEL ROOM NUMBER-59,', 'Ckumar123@'),
('derry', 'Derry', 'derry@gmail.com', '0204838830', 'Bani & B-301', 'derry'),
('esther ', 'Pick Up ', 'esther@gmail.com', '0940203920', 'Pent 902', 'esther'),
('haha', 'pickp', 'haha@g.com', '3453', 'bani', 'haha'),
('Jonny', 'Jonny', 'jonny@gmail.com', '233203307770', 'Legon Hall P313', 'jonny'),
('Kwaku', 'Kwaku', 'kwaku@gmail.com', '0204838830', 'TF & A121', 'kwaku'),
('kwame', 'Kwame', 'kwame@gmail.com', '0502350919', 'Bani', 'kwame'),
('Mellisa', 'pickup', 'mellisa@gmail.com', '03949', 'pennt', 'mellisa'),
('nidha', 'nidha', 'nidha@gmail.com', '998696572', 'Maharashtra', 'suhail'),
('philcho', 'Marfo Philip', 'philcho98@gmail.com', '0502350919', 'Pentagon', 'philly'),
('Phoebe01', 'Phoebe', 'phoebe@gmail.com', '2342345329', 'Pent', 'phoebe'),
('pimpong', 'pimpong', 'pimpong@gmail.com', '0505715724', 'Nelson', 'pimpong'),
('pine', 'pine', 'pine@gmail.com', '0502350919', 'Pine room', 'pine'),
('pineyy', 'piney', 'pineyy@gmail.com', '999', 'piney', 'pineyy'),
('pratheek083', 'Pratheek Shiri', 'pratheek@gmail.com', '8779546521', 'Hyderabad', 'pratheek'),
('rakshithk00', 'Rakshith Kotian', 'rakshith@gmail.com', '9547123658', 'Gujarath', 'rakshith'),
('rimaa', 'rima sh', 'rima@gmail.com', '9487810674', 'fdgd', 'rima'),
('salt', 'saltty', 'salt@gmail.com', '93039', 'salt', 'salt'),
('sub', 'sub', 'sub@gmail.com', '982092', 'sub', 'sub'),
('sugar', 'pickup', 'sugar@gmail.com', '2093', '93ojmoiqe90', 'sugar'),
('Wendy', 'Pick Up', 'wendy@gmail.com', '0203939292', 'Pent, block B', 'Wendy'),
('yam', 'yam', 'yam@gmail.com', '092438', 'yammy', 'yam');

-- --------------------------------------------------------

--
-- Table structure for table `customer_app`
--

DROP TABLE IF EXISTS `customer_app`;
CREATE TABLE IF NOT EXISTS `customer_app` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `password_hash` varchar(256) NOT NULL,
  `salt` varchar(256) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
CREATE TABLE IF NOT EXISTS `data` (
  `average_rating` varchar(50) NOT NULL,
  `image_url` varchar(500) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_price` varchar(100) NOT NULL,
  PRIMARY KEY (`average_rating`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`average_rating`, `image_url`, `item_name`, `item_price`) VALUES
('3.4', 'http://192.168.43.6:8282//customer//load-image/loaf.jpg', 'Sugar Loaf\r\n\r\nDescription:\r\nGreat aroma, Super sweet and Juicy Pineapple', '3'),
('3.5', 'http://192.168.43.6:8282//customer//load-image/smoothCayenne.jpg', 'Smooth Cayenne\r\n\r\nDescription:\r\nThe flavor is exceedingly sweet with hints of honey. ', '2'),
('4.8', 'http://192.168.43.6:8282//customer//load-image/md2.jpg', 'MD2\r\n\r\nDescription:\r\nYour go-to soft and juicy pineapple', '2');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
CREATE TABLE IF NOT EXISTS `food` (
  `F_ID` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `price` int(30) NOT NULL,
  `description` varchar(200) NOT NULL,
  `R_ID` int(30) NOT NULL,
  `images_path` varchar(200) NOT NULL,
  `options` varchar(10) NOT NULL DEFAULT 'ENABLE',
  PRIMARY KEY (`F_ID`,`R_ID`),
  KEY `R_ID` (`R_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`F_ID`, `name`, `price`, `description`, `R_ID`, `images_path`, `options`) VALUES
(58, 'MD2', 2, 'Great aroma, Super sweet and Juicy Pineapple', 1, 'images/md2.jpg', 'ENABLE'),
(59, 'Sugar Loaf', 3, 'The flavor is exceedingly sweet with hints of honey. The edible core is just as sweet to the taste.', 2, 'images/loaf.jpg', 'ENABLE'),
(60, 'Smooth Cayenne', 2, 'Your go-to soft and juicy pineapple', 3, 'images/smoothcayenne.jpg', 'ENABLE');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_ID` int(30) NOT NULL AUTO_INCREMENT,
  `F_ID` int(30) NOT NULL,
  `foodname` varchar(30) NOT NULL,
  `price` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `order_date` date NOT NULL,
  `username` varchar(30) NOT NULL,
  `R_ID` int(30) NOT NULL,
  PRIMARY KEY (`order_ID`),
  KEY `F_ID` (`F_ID`),
  KEY `username` (`username`),
  KEY `R_ID` (`R_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_ID`, `F_ID`, `foodname`, `price`, `quantity`, `order_date`, `username`, `R_ID`) VALUES
(75, 58, 'MD2', 2, 2, '2019-11-01', 'philcho', 1),
(76, 59, 'Sugar Loaf', 3, 2, '2019-11-01', 'philcho', 2),
(77, 60, 'Smooth Cayenne', 2, 2, '2019-11-01', 'philcho', 3),
(78, 58, 'MD2', 2, 1, '2019-11-01', 'philcho', 1),
(79, 59, 'Sugar Loaf', 3, 1, '2019-11-01', 'philcho', 2),
(80, 58, 'MD2', 2, 3, '2019-11-01', 'philcho', 1),
(81, 59, 'Sugar Loaf', 3, 1, '2019-11-01', 'philcho', 2),
(82, 58, 'MD2', 2, 3, '2019-11-01', 'philcho', 1),
(83, 59, 'Sugar Loaf', 3, 1, '2019-11-01', 'philcho', 2),
(84, 58, 'MD2', 2, 3, '2019-11-01', 'philcho', 1),
(85, 59, 'Sugar Loaf', 3, 1, '2019-11-01', 'philcho', 2),
(86, 58, 'MD2', 2, 3, '2019-11-01', 'philcho', 1),
(87, 59, 'Sugar Loaf', 3, 1, '2019-11-01', 'philcho', 2),
(88, 58, 'MD2', 2, 3, '2019-11-01', 'philcho', 1),
(141, 59, 'Sugar Loaf', 3, 3, '2019-11-07', 'sub', 2),
(142, 60, 'Smooth Cayenne', 2, 3, '2019-11-07', 'pineyy', 3),
(143, 60, 'Smooth Cayenne', 2, 3, '2019-11-07', 'haha', 3),
(144, 60, 'Smooth Cayenne', 2, 3, '2019-11-07', 'haha', 3),
(145, 59, 'Sugar Loaf', 3, 2, '2019-11-15', 'yam', 2),
(146, 59, 'Sugar Loaf', 3, 2, '2019-11-15', 'yam', 2),
(147, 59, 'Sugar Loaf', 3, 3, '2019-11-17', 'sugar', 2),
(148, 59, 'Sugar Loaf', 3, 3, '2019-11-17', 'salt', 2),
(149, 59, 'Sugar Loaf', 3, 2, '2019-11-18', 'aa', 2),
(150, 59, 'Sugar Loaf', 3, 2, '2019-11-18', 'aa', 2),
(151, 59, 'Sugar Loaf', 3, 2, '2019-11-27', 'esther ', 2),
(152, 59, 'Sugar Loaf', 3, 1, '2019-12-02', 'Wendy', 2),
(153, 60, 'Smooth Cayenne', 2, 2, '2019-12-03', 'Mellisa', 3);

-- --------------------------------------------------------

--
-- Table structure for table `orders_app`
--

DROP TABLE IF EXISTS `orders_app`;
CREATE TABLE IF NOT EXISTS `orders_app` (
  `f_id` varchar(50) NOT NULL,
  `foodname` varchar(200) DEFAULT NULL,
  `price` varchar(200) DEFAULT NULL,
  `order_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `quantity` varchar(200) DEFAULT NULL,
  `username` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders_app`
--

INSERT INTO `orders_app` (`f_id`, `foodname`, `price`, `order_date`, `quantity`, `username`) VALUES
('53117', 'sss', '20', '2019-11-17 00:00:00.000000', '2', 'aa'),
('68201', 'sss', '20', '2019-11-17 17:48:57.759010', '2', 'aa'),
('19618', 'sss', '20', '2019-11-17 17:50:55.544848', '2', 'aa'),
('72439', 'sss', '20', '2019-11-18 11:09:06.011785', '2', 'salt'),
('12473', 'sss', '33', '2019-11-18 16:30:33.805806', '2', 'aa'),
('30543', 'sss', '33', '2019-11-18 16:47:20.314001', '2', 'salt'),
('59282', 'sss', '33', '2019-11-18 16:52:32.526487', '2', 'salt'),
('75300', 'sss', '33', '2019-11-25 19:11:31.686396', '2', 'salt'),
('45176', 'sss', '33', '2019-12-02 09:27:43.613659', '2', 'haha'),
('92529', 'sss', '33', '2019-12-03 12:24:19.668630', '2', 'salt'),
('65246', 'sss', '33', '2019-12-03 15:19:26.088082', '2', 'aa'),
('37591', 'sss', '33', '2019-12-03 15:19:28.127115', '2', 'aa'),
('30323', 'sss', '33', '2019-12-03 15:27:17.451942', '2', 'aa'),
('42365', 'sss', '33', '2019-12-03 15:32:38.624823', '2', 'aa');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
