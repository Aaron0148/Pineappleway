<?php
session_start();
require 'connection.php';
$conn = Connect();
if(!isset($_SESSION['login_user'])){
header("location: customerlogin.php"); 
}

unset($_SESSION["cart"]);
?>

<html>

  <head>
    <title> Cart | Pineapple Way </title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="css/COD.css">
  <link rel="stylesheet" type = "text/css" href ="css/bootstrapa.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>

  <body>

      <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php">Pineapple Way</a>
        </div>
        <div class="collapse navbar-collapse " id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active" ><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
          </ul>

<?php
if (isset($_SESSION['login_user'])) {
  ?>
           <ul class="nav navbar-nav navbar-right">
            <li><a href="#"> Welcome <?php echo $_SESSION['login_user']; ?> </a></li>
            <li><a href="pinelist.php"> Pine Zone </a></li>
            <li><a href="cart.php"> Cart
              (<?php
              if(isset($_SESSION["cart"])){
              $count = count($_SESSION["cart"]); 
              echo "$count"; 
            }
              else
                echo "0";
              ?>)
             </a></li>
            <li><a href="logout.php"> Log Out </a></li>
          </ul>
  <?php        
}
else {

  ?>
           
            
   <!--User login and sign up-->         
<ul class="nav navbar-nav navbar-right">
            <li><a href="customersignup.php"  role="button"> Sign Up </a>
    </li>
            <li><a href="customerlogin.php"  role="button"> Login </a>
            </li>
          </ul>

<?php
}
?>
       </div>
      </div>
    </nav>



        <div class="container">
          <div class="jumbotron">
            <h1 class="text-center" style="color: green;"> Order Successful.</h1>
          </div>
        </div>
        <br>

<h1 class="text-center"> Thank you for Ordering Pineapple Way! The ordering process is now complete.</h1>

        </body>

</html>