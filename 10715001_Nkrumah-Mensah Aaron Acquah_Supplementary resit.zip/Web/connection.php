<?php

function Connect()
{
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "pine";

	//Create Connection
	$conn = mysqli_connect('localhost', 'root', '', 'pine');
    
	
	return $conn;
}
?>




