<!--Connects to the database and saves the inputted values into the database table contact and displays a message after successful entry of data-->
<?php
session_start();
?>


<?php
if (isset($_POST['submit'])){
require 'connection.php';
$conn = Connect();

$Name = $conn->real_escape_string($_POST['name']);
$Email_Id = $conn->real_escape_string($_POST['email']);
$Mobile_No = $conn->real_escape_string($_POST['mobile']);
$Subject = $conn->real_escape_string($_POST['subject']);
$Message = $conn->real_escape_string($_POST['message']);

$query = "INSERT into contact(Name,Email,Mobile,Subject,Message) VALUES('$Name','$Email_Id','$Mobile_No','$Subject','$Message')";
$success = $conn->query($query);

if (!$success){
  die("Couldnt enter data: ".$conn->error);
}
else{
    echo "Thanks for getting in touch with Pineapple Way";
}
$conn->close();
}
?>
<!-- Database ends-->


<html>

  <head>
    <title> Contact | Pineapple Way </title>
  </head>


  <link rel="stylesheet" type = "text/css" href ="css/bootstrapa.min.css"s>
 

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php">Pineapple Way</a>
        </div>
        <div class="collapse navbar-collapse " id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active" ><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
          </ul>
<!--if user is logged into the account display-->
<?php
         
if (isset($_SESSION['login_user'])) {
  ?>
           <ul class="nav navbar-nav navbar-right">
            <li><a href="#"> Welcome <?php echo $_SESSION['login_user']; ?> </a></li>
            <li><a href="pinelist.php"> Pine Zone </a></li>
            <li><a href="cart.php"> Cart
              (<?php
              if(isset($_SESSION["cart"])){
              $count = count($_SESSION["cart"]); 
              echo "$count"; 
            }
              else
                echo "0";
              ?>)
             </a></li>
            <li><a href="logout.php"> Log Out </a></li>
          </ul>
  <?php        
}
else {

  ?>
           
            
   <!-- or User login and sign up-->         
<ul class="nav navbar-nav navbar-right">
            <li><a href="customersignup.php"  role="button"> Sign Up </a>
    </li>
            <li><a href="customerlogin.php"  role="button"> Login </a>
            </li>
          </ul>

<?php
}
?>
       </div>
      </div>
    </nav>
    <br>

    

    <div class="col-xs-12 line"><hr></div>

    <div class="container" >
    <div class="col-md-5" style="float: none; margin: 0 auto;">
      <div class="form-area">
        <form method="POST" action="">
        <br style="clear: both">
            <h3 style="margin-bottom: 25px; color: black; text-align: center; font-size: 20px;"> Have some questions? Contact us.</h3>

          <div class="form-group">
            <input type="text" class="form-control" id="name" name="name" placeholder="Name" required autofocus="">
          </div>

          <div class="form-group">
            <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
          </div>     

          <div class="form-group">
            <input type="tel" class="form-control" id="mobile" name="mobile" placeholder="Mobile Number" required>
          </div>

          <div class="form-group">
            <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
          </div>
          <div class="form-group">
           <textarea class="form-control" type="textarea" id="message" name="message" placeholder="Message" maxlength="200" rows="6"></textarea>
          
          </div> 
          <input type="submit" name="submit" type="button" id="submit" name="submit" class="btn btn-success pull-right"/>    
        </form>

        
      </div>
    </div>
      
    </div>

    
     </body>

  
</html>
