<?php

require 'connection.php';
$conn = Connect();

$username = $conn->real_escape_string($_POST['username']);
$contact = $conn->real_escape_string($_POST['contact']);
$fullname = $conn->real_escape_string($_POST['fullname']);
$email = $conn->real_escape_string($_POST['email']);
$address = $conn->real_escape_string($_POST['address']);
$password = $conn->real_escape_string($_POST['password']);

$query = "INSERT INTO CUSTOMER(fullname,username,email,contact,address,password) VALUES('" . $fullname . "','" . $username . "','" . $email . "','" . $contact . "','" . $address ."','" . $password ."')";
$success = $conn->query($query);

if (!$success){
	die("Couldnt enter data:Username already taken ".$conn->error);
}

$conn->close();

?>


<html>

  <head>
    <title> Account successful | Pineapple Way </title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="css/manager_registered_success.css">
  <link rel="stylesheet" type = "text/css" href ="css/bootstrapc.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>

  <body>

  
       <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php">Pineapple Way</a>
        </div>
        <div class="collapse navbar-collapse " id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active" ><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
          </ul>

<?php
if (isset($_SESSION['login_user'])) {
  ?>
           <ul class="nav navbar-nav navbar-right">
            <li><a href="#"> Welcome <?php echo $_SESSION['login_user']; ?> </a></li>
            <li><a href="pinelist.php"> Pine Zone </a></li>
            <li><a href="cart.php"> Cart
              (<?php
              if(isset($_SESSION["cart"])){
              $count = count($_SESSION["cart"]); 
              echo "$count"; 
            }
              else
                echo "0";
              ?>)
             </a></li>
            <li><a href="logout.php"> Log Out </a></li>
          </ul>
  <?php        
}
else {

  ?>
           
            
   <!--User login and sign up-->         
<ul class="nav navbar-nav navbar-right">
            <li><a href="customersignup.php"  role="button"> Sign Up </a>
    </li>
            <li><a href="customerlogin.php"  role="button"> Login </a>
            </li>
          </ul>

<?php
}
?>
       </div>
      </div>
    </nav>

      
          <!--add image  to the page-->
    <img src="img/pine9.jpg" style="width:100%;">


<div class="container">
    <br><br><br>
	<div class="wells" style="text-align: center;">
		<h2> <?php echo "Hey $username Welcome to Pineapple Way !" ?> </h2>
		<h1>Your account has been created.</h1>
		<p>Login Now from <a href="customerlogin.php">HERE</a></p>
	</div>
    
</div>


    </body>
</html>