<html>
<head>
    <title> Signup | Pineapple Way </title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="css/bootstrapa.min.css">


  <body>

        <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php">Pineapple Way</a>
        </div>
        <div class="collapse navbar-collapse " id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active" ><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
          </ul>
                <!--if user is logged into the account display-->
<?php
if (isset($_SESSION['login_user'])) {
  ?>
           <ul class="nav navbar-nav navbar-right">
            <li><a href="#"> Welcome <?php echo $_SESSION['login_user']; ?> </a></li>
            <li><a href="pinelist.php"> Pine Zone </a></li>
            <li><a href="cart.php"> Cart
              (<?php
              if(isset($_SESSION["cart"])){
              $count = count($_SESSION["cart"]); 
              echo "$count"; 
            }
              else
                echo "0";
              ?>)
             </a></li>
            <li><a href="logout.php"> Log Out </a></li>
          </ul>
  <?php        
}
else {

  ?>
           
            
   <!--User login and sign up-->         
<ul class="nav navbar-nav navbar-right">
            <li><a href="customersignup.php"  role="button"> Sign Up </a>
    </li>
            <li><a href="customerlogin.php"  role="button"> Login </a>
            </li>
          </ul>

<?php
}
?>
       </div>
      </div>
    </nav>

      <br><br><br>
    <div class="container">
      <div class="col-md-5 col-md-offset-4">
      <div class="panel panel-primary">
        <img src = "images/LogoImage.jpg" width= "100"> Create Your Pine Account Now
        <div class="panel-body">
        <form role="form" action="customer_registered_success.php" method="POST">
         
    

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="username"><span class="text-danger" style="margin-right: 5px;">*</span> Username: </label>
            <div class="input-group">
              <input class="form-control" id="username" type="text" name="username" placeholder="Your Username" required="">
              <span class="input-group-btn">
                  <label class="btn btn-primary"></label>
            
              </span>
            </div>           
          </div>
        </div>
            <div class="row">
                  <div class="form-group col-xs-12">
            <label for="fullname"><span class="text-danger" style="margin-right: 5px;">*</span> Full name </label>
            <div class="input-group">
              <input class="form-control" id="fullname" type="text" name="fullname" placeholder="Full name" required="" autofocus="">
              <span class="input-group-btn">
                <label class="btn btn-primary"></label>
            
              </span>
            </div>   
          </div>
          </div>
       
            
        
        <div class="row">
          <div class="form-group col-xs-12">
            <label for="email"><span class="text-danger" style="margin-right: 5px;">*</span> Email: </label>
            <div class="input-group">
              <input class="form-control" id="email" type="email" name="email" placeholder="Email" required="">
              <span class="input-group-btn">
                  <label class="btn btn-primary"></label>
            </span>
            
            </div>           
          </div>
        </div>

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="contact"><span class="text-danger" style="margin-right: 5px;">*</span> Contact: </label>
              <div class="input-group">
              <input class="form-control" id="contact" type="tel" name="contact" placeholder="Contact" required="">
              <span class="input-group-btn">
                  <label class="btn btn-primary"></label>
            </span>
              
            </div>           
          </div>
        </div>
 

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="address"><span class="text-danger" style="margin-right: 5px;">*</span> Hall/Block/Room Number  </label>
            <div class="input-group">
              <input class="form-control" id="address" type="text" name="address" placeholder="Enter Hall & Block & Room Number" required="">
              <span class="input-group-btn">
                  <label class="btn btn-primary"></label>
              </span>
            </div>           
          </div>
        </div>
            
        <!div class="row">
            
            
            
  
        <div class="row">
          <div class="form-group col-xs-12">
            <label for="password"><span class="text-danger" style="margin-right: 5px;">*</span> Password: </label>
            <div class="input-group">
              <input class="form-control" id="password" type="password" name="password" placeholder="Password" required="">
              <span class="input-group-btn">
                <label class="btn btn-primary"></label>
            </span>
              
            </div>           
          </div>
        </div>

        

        <div class="row">
          <div class="form-group col-xs-4">
              <button class="btn btn-primary" type="submit">Submit</button>
          </div>

        </div>
        <label style="margin-left: 5px;">or</label> <br>
       <label style="margin-left: 5px;"><a href="customerlogin.php">Have an account? Login.</a></label>

        </form>
 
        </div>
        
      </div>
      
    </div>
    </div>
    </body>
    
</html>