    <?php
include('login.php'); 

if(isset($_SESSION['login_user'])){
header("location: pinelist.php"); 
}
?>

<!DOCTYPE html>
<html>

  <head>
    <title> Guest Login | Pineapple Way </title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="css/managerlogin.css">
  <link rel="stylesheet" type = "text/css" href ="css/bootstrapa.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
    
    

  <body>


       <nav class="navbar navbar-inverse navbar-fixed-top navigation-clean-search" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php">Pineapple Way</a>
        </div>
        <div class="collapse navbar-collapse " id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active" ><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
          </ul>

<?php
if (isset($_SESSION['login_user'])) {
  ?>
           <ul class="nav navbar-nav navbar-right">
            <li><a href="#"> Welcome <?php echo $_SESSION['login_user']; ?> </a></li>
            <li><a href="pinelist.php"> Pine Zone </a></li>
            <li><a href="cart.php"> Cart
              (<?php
              if(isset($_SESSION["cart"])){
              $count = count($_SESSION["cart"]); 
              echo "$count"; 
            }
              else
                echo "0";
              ?>)
             </a></li>
            <li><a href="logout.php"> Log Out </a></li>
          </ul>
  <?php        
}
else {

  ?>
           
            
   <!--User login and sign up-->         
<ul class="nav navbar-nav navbar-right">
            <li><a href="customersignup.php"  role="button"> Sign Up </a>
    </li>
            <li><a href="customerlogin.php"  role="button"> Login </a>
            </li>
          </ul>

<?php
}
?>
       </div>
      </div>
    </nav>
      
      <br><br><br>

    
   <div class="container" style="margin-top: 6%; margin-bottom: 2%;">
      <div class="col-md-5 col-md-offset-4">
      <div class="panel panel-primary">
        <img src = "images/LogoImage.jpg" width= "100"> LOGIN
        <div class="panel-body">
          
        <form action="" method="POST">
          
        <div class="row">
          <div class="form-group col-xs-12">
            <label for="username"><span class="text-danger" style="margin-right: 5px;">*</span> Username: </label>
            <div class="input-group">
              <input class="form-control" id="username" type="text" name="username" placeholder="Username" required="" autofocus="">
              <span class="input-group-btn">
                <label class="btn btn-primary"></label>
            </span>
             
            </div>           
          </div>
        </div>

        <div class="row">
          <div class="form-group col-xs-12">
            <label for="password"><span class="text-danger" style="margin-right: 5px;">*</span> Password: </label>
            <div class="input-group">
              <input class="form-control" id="password" type="password" name="password" placeholder="Password" required="">
              <span class="input-group-btn">
                <label class="btn btn-primary"></label>
            </span>
              
            </div>           
          </div>
        </div>
            
        <div class="row">
          <div class="form-group col-xs-4">
              <button class="btn btn-primary" name="submit" type="submit" value=" Login ">Submit</button>
          </div>

        </div>
        <label style="margin-left: 5px;">or</label> <br>
     <label style="margin-left: 5px;"><center><a href="customersignup.php">Create a new account.</a></center></label>

        </form>
        </div>     
      </div>      
    </div>
    </div>
    </body>
</html>
    